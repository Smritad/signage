<!doctype html>
<html lang="en">
    
<head>
    @include('components.backend.head')
</head>
	   
		@include('components.backend.header')

	    <!--start sidebar wrapper-->	
	    @include('components.backend.sidebar')
	   <!--end sidebar wrapper-->

    
     <div class="page-body">
          <div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-6">
                </div>
                <div class="col-6">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">                                       
                        <svg class="stroke-icon">
                          <use href="../assets/svg/icon-sprite.svg#stroke-home"></use>
                        </svg></a></li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid">
            <div class="row">
              <!-- Zero Configuration  Starts-->
              <div class="col-sm-12">
                <div class="card">
                  <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center mb-4">
								<nav aria-label="breadcrumb" role="navigation">
									<ol class="breadcrumb mb-0">
										<li class="breadcrumb-item">
											<a href="{{ route('shiprocket-details.index') }}">Home</a>
										</li>
										<li class="breadcrumb-item active" aria-current="page">Stock</li>
									</ol>
								</nav>

							</div>


                  
                    <div class="table-responsive custom-scrollbar">
<table class="display" id="basic-1">
    <thead>
        <tr>
            <th>#</th>
            <th>User Name</th>
            <th>Email</th>
            <th>Total Amount</th>
            <th>Transaction Id</th>
            <th>Date</th>
            <th>Order Details</th>
            <th>Order Status</th>
        </tr>
    </thead>
    <tbody>
        @foreach($orders as $key => $order)
        <tr>
            <td>{{ $key + 1 }}</td>
            <td>{{ $order->customer_name }}</td>
            <td>{{ $order->customer_email }}</td>
            <td>₹{{ number_format($order->total_price, 2) }}</td>
            <td>{{ $order->payment_id }}</td>
            <td>{{ \Carbon\Carbon::parse($order->created_at)->format('d M Y') }}</td>
            <td>
                <a href="{{ route('admin.Orderdetails.index', $order->id) }}" class="btn btn-sm btn-primary"
                   >Order details</a>
            </td>
            <td>
                <a href="{{ route('admin.shiprocket.ship', $order->order_id) }}" class="btn btn-sm btn-primary"
                   onclick="return confirm('Are you sure you want to ship this order?');">Ship Now</a>
            </td>

        </tr>
        @endforeach
    </tbody>
</table>


                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
            <!-- footer start-->
             @include('components.backend.footer')
      </div>
    </div>

        @include('components.backend.main-js')
<script>
    $(document).ready(function() {
        $('#basic').DataTable();
    });
</script>
</body>

</html>