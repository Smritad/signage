<?php

namespace App\Http\Controllers\Backend\offer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class OfferController extends Controller
{
    /* ─── List all offers ─── */
    public function index()
    {
        $offers = DB::table('offers')
            ->whereNull('deleted_by')
            ->orderByDesc('created_at')
            ->get()
            ->map(function ($offer) {
                $offer->products_decoded = json_decode($offer->products, true) ?? [];
                return $offer;
            });

        return view('backend.offer-page.offers-details.index', compact('offers'));
    }

    /* ─── Show create form ─── */
    public function create()
    {
        // All active products — we need product_name + price_variants for the form
        $products = DB::table('products_details')
            ->whereNull('deleted_at')   // show ALL non-deleted products regardless of is_active
            ->select('id', 'product_name', 'price_variants', 'category_id')
            ->orderBy('product_name')
            ->get()
            ->map(function ($p) {
                // price_variants: [{"price":"1999","offer_price":"1799","measurement_unit":"100ml"}, ...]
                $p->price_variants = json_decode($p->price_variants, true) ?? [];
                return $p;
            });

        // Categories (for potential category-level product picking)
        $categories = DB::table('category_details')
            ->whereNull('deleted_at')
            ->orderBy('category_name')
            ->get();

        return view('backend.offer-page.offers-details.create', compact('products', 'categories'));
    }

    /* ─── Store new offer ─── */
    public function store(Request $request)
    {
        $request->validate([
            'offer_name'  => 'required|string|max:255',
            'offer_price' => 'required|numeric|min:0',
            'products'    => 'required|string',   // JSON string
        ], [
            'offer_name.required'  => 'Offer name is required.',
            'offer_price.required' => 'Offer price is required.',
            'products.required'    => 'Please add at least one product.',
        ]);

        // Validate products JSON is not empty array
        $productsArr = json_decode($request->products, true);
        if (!is_array($productsArr) || count($productsArr) === 0) {
            return back()->withErrors(['products' => 'Please add at least one product to the offer.'])
                         ->withInput();
        }

        DB::table('offers')->insert([
            'offer_name'  => $request->offer_name,
            'offer_price' => $request->offer_price,
            'products'    => $request->products,   // JSON
            'is_active'   => $request->is_active ?? 1,
            'created_by'  => Auth::id(),
            'created_at'  => now(),
            'updated_at'  => now(),
        ]);

        return redirect()->route('offer-details.index')
                         ->with('success', '✅ Offer "' . $request->offer_name . '" created successfully!');
    }

    /* ─── Show edit form ─── */
    public function edit($id)
    {
        $offer = DB::table('offers')->where('id', $id)->whereNull('deleted_by')->first();
        if (!$offer) abort(404);

        $offer->products_decoded = json_decode($offer->products, true) ?? [];

        $products = DB::table('products_details')
            ->whereNull('deleted_at')
            ->select('id', 'product_name', 'price_variants', 'category_id')
            ->orderBy('product_name')
            ->get()
            ->map(function ($p) {
                $p->price_variants = json_decode($p->price_variants, true) ?? [];
                return $p;
            });

        $categories = DB::table('category_details')
            ->whereNull('deleted_at')
            ->orderBy('category_name')
            ->get();

        return view('backend.offer-page.offers-details.edit', compact('offer', 'products', 'categories'));
    }

    /* ─── Update offer ─── */
    public function update(Request $request, $id)
    {
        $request->validate([
            'offer_name'  => 'required|string|max:255',
            'offer_price' => 'required|numeric|min:0',
            'products'    => 'required|string',
        ]);

        $productsArr = json_decode($request->products, true);
        if (!is_array($productsArr) || count($productsArr) === 0) {
            return back()->withErrors(['products' => 'Please add at least one product.'])->withInput();
        }

        DB::table('offers')->where('id', $id)->update([
            'offer_name'  => $request->offer_name,
            'offer_price' => $request->offer_price,
            'products'    => $request->products,
            'is_active'   => $request->is_active ?? 1,
            'updated_by'  => Auth::id(),
            'updated_at'  => now(),
        ]);

        return redirect()->route('offer-details.index')
                         ->with('message', '✅ Offer updated successfully!');
    }

    /* ─── Soft delete ─── */
    public function destroy($id)
    {
        DB::table('offers')->where('id', $id)->update([
            'deleted_by' => Auth::id(),
            'deleted_at' => now(),
        ]);

        return redirect()->route('offer-details.index')
                         ->with('success', 'Offer deleted.');
    }

    /* ─── Toggle active status (AJAX) ─── */
    public function toggleStatus(Request $request, $id)
    {
        $offer = DB::table('offers')->where('id', $id)->first();
        if (!$offer) return response()->json(['error' => 'Not found'], 404);

        DB::table('offers')->where('id', $id)->update([
            'is_active'  => $offer->is_active ? 0 : 1,
            'updated_by' => Auth::id(),
            'updated_at' => now(),
        ]);

        return response()->json(['success' => true, 'is_active' => !$offer->is_active]);
    }
}