<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class UpdateShiprocketStatus extends Command
{
    protected $signature = 'shiprocket:update-status';
    protected $description = 'Update latest delivery status and courier info for orders from Shiprocket';

    public function handle()
    {
        $this->info("🔐 Authenticating with Shiprocket...");

        $auth = Http::post('https://apiv2.shiprocket.in/v1/external/auth/login', [
            'email' => 'smrita@matrixbricks.com',
            'password' => 'n9*DRd52M1eXB6gh',
        ]);

        if ($auth->failed()) {
            $this->error("❌ Failed to authenticate with Shiprocket.");
            return Command::FAILURE;
        }

        $token = $auth->json()['token'];
        $this->info("✅ Authenticated. Fetching orders...");

        $orders = DB::table('order_details')
            ->whereNotNull('shipment_id')
            ->get();

        foreach ($orders as $order) {
            $this->info("🔍 Tracking Shipment ID: {$order->shipment_id}");

            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $token,
                'Content-Type' => 'application/json',
            ])->get("https://apiv2.shiprocket.in/v1/external/courier/track/shipment/{$order->shipment_id}");

            if ($response->failed()) {
                $this->error("❌ Failed to fetch tracking for Order ID {$order->id}");
                continue;
            }

            $data = $response->json();

            if (!isset($data['tracking_data'])) {
                $this->warn("⚠️ No tracking data for Order ID {$order->id}");
                continue;
            }

            $tracking = $data['tracking_data'];
            $shipmentTrack = $tracking['shipment_track'][0] ?? [];

            // Prepare update fields
            $updateData = [
                'channel_order_id'    => $tracking['channel_order_id'] ?? $order->channel_order_id,
                'awb_code'            => $shipmentTrack['awb_code'] ?? $order->awb_code,
                'courier_company_id'  => $shipmentTrack['courier_company_id'] ?? $order->courier_company_id,
                'courier_name'        => $shipmentTrack['courier_name'] ?? $order->courier_name,
                'courier_status'      => $shipmentTrack['current_status'] ?? $order->courier_status,
                'delivery_status'     => $tracking['shipment_status'] ?? $order->delivery_status,
                'updated_at'          => now(),
            ];

            DB::table('order_details')
                ->where('id', $order->id)
                ->update($updateData);

            $this->info("✅ Updated Order ID {$order->id} with tracking info.");
            Log::info('[Shiprocket] Updated order_details', [
                'order_id' => $order->order_id,
                'shipment_id' => $order->shipment_id,
                'updated_fields' => $updateData,
            ]);
        }

        $this->info("🎯 All eligible orders processed.");
        return Command::SUCCESS;
    }
}
