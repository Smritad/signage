<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * Register the commands for the application.
     */
    protected $commands = [
    \App\Console\Commands\UpdateShiprocketStatus::class,
];

protected function schedule(Schedule $schedule)
{
    $schedule->command('shiprocket:update-status')->everyMinute();
}

}
